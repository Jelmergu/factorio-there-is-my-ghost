data:extend({
    {
        type = "custom-input",
        name = "there-is-my-ghost-toggle",
        key_sequence = "CONTROL + G",
    }
})